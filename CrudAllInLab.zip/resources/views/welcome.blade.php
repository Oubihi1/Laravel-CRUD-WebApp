<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>ALLINLAB</title>
    </head>
    <body>
        <h1>Welcome in ALLINLAB_CRUD-APP</h1>
        <button><a href="http://127.0.0.1:8000/member"> Show all of members</a></button> <br>
        <button ><a href="http://127.0.0.1:8000/member/create">Create a new member</a></button>   
    </body>
</html>
